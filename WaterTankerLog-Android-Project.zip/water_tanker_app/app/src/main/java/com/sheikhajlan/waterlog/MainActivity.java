package com.sheikhajlan.waterlog;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.database.*;
import android.database.sqlite.*;
import android.graphics.Typeface;
import android.net.Uri;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    DB db; LinearLayout root, listBox; EditText dateIn,timeIn,nameIn,qtyIn,driverIn,notesIn,searchIn; Button saveBtn; long editId=-1;
    int green=0xFF176B52, dark=0xFF124A38, pale=0xFFEAF4EF;
    @Override public void onCreate(Bundle b){super.onCreate(b); db=new DB(this); build(); render();}
    TextView text(String s,int size,boolean bold){ TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(0xFF17211D); if(bold)t.setTypeface(null,Typeface.BOLD); t.setPadding(2,5,2,5); return t; }
    EditText field(String hint,String value){ EditText e=new EditText(this); e.setSingleLine(true); e.setText(value==null?"":value); e.setHint(hint); e.setTextSize(16); e.setPadding(18,8,18,8); e.setBackgroundTintList(android.content.res.ColorStateList.valueOf(green)); return e; }
    Button button(String label){ Button b=new Button(this); b.setText(label); b.setAllCaps(false); b.setTextColor(0xFFFFFFFF); b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(green)); return b; }
    void build(){
        ScrollView scroll=new ScrollView(this); root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(18,12,18,24); root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL); scroll.addView(root); setContentView(scroll);
        TextView header=text("💧 سجل تعبئة خزان الماء",24,true); header.setTextColor(0xFFFFFFFF); header.setBackgroundColor(dark); header.setPadding(18,22,18,22); root.addView(header);
        TextView home=text("منزل الشيخ عجلان محمد",17,true); home.setTextColor(green); home.setPadding(8,12,8,12); root.addView(home);
        root.addView(text("تسجيل تعبئة جديدة",19,true));
        dateIn=field("التاريخ (مثال 2026-10-16)",today()); root.addView(dateIn);
        timeIn=field("الوقت (مثال 14:30)",nowTime()); root.addView(timeIn);
        nameIn=field("اسم المستلم *",""); root.addView(nameIn);
        qtyIn=field("كمية الماء (مثال 19 طن أو 19000 لتر)",""); root.addView(qtyIn);
        driverIn=field("اسم السائق أو رقم الوايت (اختياري)",""); root.addView(driverIn);
        notesIn=field("ملاحظات (اختياري)",""); root.addView(notesIn);
        saveBtn=button("حفظ عملية التعبئة"); saveBtn.setTextSize(17); LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,-2); bp.setMargins(0,12,0,10); root.addView(saveBtn,bp); saveBtn.setOnClickListener(v->save());
        Button export=button("تصدير السجل ومشاركته (CSV)"); root.addView(export); export.setOnClickListener(v->exportCsv());
        root.addView(text("سجل التعبئات السابقة",20,true));
        searchIn=field("بحث باسم المستلم أو التاريخ",""); root.addView(searchIn); searchIn.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){} public void onTextChanged(CharSequence s,int st,int before,int count){renderList(s.toString());} public void afterTextChanged(android.text.Editable e){}});
        listBox=new LinearLayout(this); listBox.setOrientation(LinearLayout.VERTICAL); root.addView(listBox);
    }
    String today(){return new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date());}
    String nowTime(){return new SimpleDateFormat("HH:mm",Locale.US).format(new Date());}
    void save(){String date=dateIn.getText().toString().trim(), time=timeIn.getText().toString().trim(), name=nameIn.getText().toString().trim(); if(date.isEmpty()||time.isEmpty()||name.isEmpty()){Toast.makeText(this,"يرجى إدخال التاريخ والوقت واسم المستلم",Toast.LENGTH_LONG).show();return;}
        ContentValues c=new ContentValues(); c.put("date",date); c.put("time",time); c.put("recipient",name); c.put("quantity",qtyIn.getText().toString().trim()); c.put("driver",driverIn.getText().toString().trim()); c.put("notes",notesIn.getText().toString().trim());
        if(editId<0) db.getWritableDatabase().insert("fills",null,c); else db.getWritableDatabase().update("fills",c,"id=?",new String[]{String.valueOf(editId)});
        editId=-1; nameIn.setText(""); qtyIn.setText(""); driverIn.setText(""); notesIn.setText(""); dateIn.setText(today()); timeIn.setText(nowTime()); saveBtn.setText("حفظ عملية التعبئة"); ((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(nameIn.getWindowToken(),0); Toast.makeText(this,"تم حفظ عملية التعبئة على الهاتف",Toast.LENGTH_SHORT).show(); renderList(searchIn.getText().toString());
    }
    void render(){if(listBox!=null)renderList("");}
    void renderList(String filter){listBox.removeAllViews(); Cursor c=db.getReadableDatabase().rawQuery("SELECT * FROM fills WHERE recipient LIKE ? OR date LIKE ? ORDER BY date DESC,time DESC,id DESC",new String[]{"%"+filter+"%","%"+filter+"%"}); if(c.getCount()==0){listBox.addView(text("لا توجد عمليات مسجلة بعد.",15,false)); c.close(); return;} while(c.moveToNext()){long id=c.getLong(c.getColumnIndexOrThrow("id")); String date=c.getString(c.getColumnIndexOrThrow("date")),time=c.getString(c.getColumnIndexOrThrow("time")),name=c.getString(c.getColumnIndexOrThrow("recipient")),qty=c.getString(c.getColumnIndexOrThrow("quantity")),driver=c.getString(c.getColumnIndexOrThrow("driver")),notes=c.getString(c.getColumnIndexOrThrow("notes"));
        LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(14,10,14,10); card.setBackgroundColor(pale); LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2); cp.setMargins(0,8,0,8); listBox.addView(card,cp);
        card.addView(text("📅 "+date+"    🕒 "+time,15,true)); card.addView(text("المستلم: "+name,17,true)); if(!qty.isEmpty())card.addView(text("الكمية: "+qty,15,false)); if(!driver.isEmpty())card.addView(text("السائق / الوايت: "+driver,15,false)); if(!notes.isEmpty())card.addView(text("ملاحظات: "+notes,14,false));
        LinearLayout actions=new LinearLayout(this); actions.setOrientation(LinearLayout.HORIZONTAL); Button edit=button("تعديل"); Button del=button("حذف"); actions.addView(edit,new LinearLayout.LayoutParams(0,-2,1)); actions.addView(del,new LinearLayout.LayoutParams(0,-2,1)); card.addView(actions);
        edit.setOnClickListener(v->{editId=id;dateIn.setText(date);timeIn.setText(time);nameIn.setText(name);qtyIn.setText(qty);driverIn.setText(driver);notesIn.setText(notes);saveBtn.setText("حفظ التعديلات"); root.smoothScrollTo(0,0);});
        del.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("حذف العملية؟").setMessage("هل تريد حذف سجل التعبئة هذا؟").setNegativeButton("إلغاء",null).setPositiveButton("حذف",(d,w)->{db.getWritableDatabase().delete("fills","id=?",new String[]{String.valueOf(id)});renderList(searchIn.getText().toString());}).show());
    } c.close(); }
    void exportCsv(){Cursor c=db.getReadableDatabase().rawQuery("SELECT date,time,recipient,quantity,driver,notes FROM fills ORDER BY date DESC,time DESC",null); StringBuilder s=new StringBuilder("\uFEFFاليوم/التاريخ,الوقت,اسم المستلم,كمية الماء,السائق أو الوايت,ملاحظات\n"); while(c.moveToNext()){String date=c.getString(0); String day=""; try{day=new SimpleDateFormat("EEEE",new Locale("ar")).format(new SimpleDateFormat("yyyy-MM-dd",Locale.US).parse(date));}catch(Exception e){} for(int i=0;i<6;i++){if(i==0)s.append(csv(day+" "+date));else s.append(csv(c.getString(i))); if(i<5)s.append(',');}s.append('\n');} c.close(); Intent send=new Intent(Intent.ACTION_SEND); send.setType("text/csv"); send.putExtra(Intent.EXTRA_SUBJECT,"سجل تعبئة خزان الماء - منزل الشيخ عجلان محمد"); send.putExtra(Intent.EXTRA_TEXT,s.toString()); startActivity(Intent.createChooser(send,"حفظ أو مشاركة سجل التعبئة")); }
    String csv(String x){if(x==null)x="";return "\""+x.replace("\"","\"\"")+"\"";}
    static class DB extends SQLiteOpenHelper {DB(Context c){super(c,"water_fills.db",null,1);} public void onCreate(SQLiteDatabase d){d.execSQL("CREATE TABLE fills (id INTEGER PRIMARY KEY AUTOINCREMENT,date TEXT NOT NULL,time TEXT NOT NULL,recipient TEXT NOT NULL,quantity TEXT,driver TEXT,notes TEXT)");} public void onUpgrade(SQLiteDatabase d,int old,int n){}}
}
